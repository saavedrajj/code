<?php
session_start();

//reset session

if (isset($_GET['reset'])){
    session_destroy();
    header("Location:paypal_start.php");
}

// import for further use
use PayPal\Api\Payment;


// file with information to display
require_once ("message.php");


// Step 1. Autoload the SDK Package. This will include all the files and classes to your autoloader
//         + configuration
require_once("bootstrap.php");

if(isset($_GET['createProfile'])){
    require_once ("project/payments/CreateWebProfile.php");
    $profileId = $createProfileResponse->getId();
    $_SESSION['profileId']= $profileId;
   
}
////////////////////////////
if(isset($_GET['createPayment'])){
require_once("project/payments/CreatePaymentUsingPayPal.php");

$_SESSION['approvalUrl'] = $payment->getApprovalLink();
$_SESSION['paymentId'] = $payment -> getId();
if($payment->getApprovalLink() !=""){
    header("Location:".$payment->getApprovalLink());
}

}

if(isset($_GET['updatePayment'])){
require_once("project/payments/UpdatePayment.php");
}


?>
<html>
<head>

</head>



<body>
    <a href="./">HOME</a> -> <a href="./paypal_start.php?reset">RESET</a>
    <br><a href="./paypal_start.php?createProfile">1. Create Experience Profile</a>
        <br>Profile ID =
    <?php if(isset($_SESSION['profileId'])) {
        echo $_SESSION['profileId'];
    }
    else {
        echo "none";
    }
    ?>
    <br><a href="./paypal_start.php?createPayment">2. Create Payment</a>
        
    <br><a href="./paypal_start.php?updatePayment">2. Update Payment</a>
    
        
        
        
    
        
    <?php
        //remove it in live
    echo "<hr>";
        if(isset($_GET['createPayment'])){
            echo "Redirect to PayPal-> <a href=".$approvalUrl.">".$approvalUrl."</a>";
            
            ResultPrinter::printResult("Created Payment", "Created Payment", $payment -> getId() , $request, $payment);
        }
        if(isset($_GET['updatePayment'])){
            ResultPrinter::printResult("Update Payment", "PatchRequest", $paymentId, $patchRequest, null);
            echo "Updated payment:<br>";
             
            $createdPayment =  Payment::get($paymentId, $apiContext);
            ResourceBundle::printOutput($createdPayment);
        
        }
            
    echo "<hr>";
    ?>
    <form id="myContainer" method="post" action="paypal_start.php?createPayment"></form>
    <script>
      window.paypalCheckoutReady = function () {
        paypal.checkout.setup('jmb@test.com', {
            environment: 'sandbox',
            container: 'myContainer'
          });
      };
    </script>

    <script src="//www.paypalobjects.com/api/checkout.js" async></script>
    
    
    </body>
</html>

