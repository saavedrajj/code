<?php
if (isset($_GET['success']) and $_GET['success'] == "false"){
    echo "<center>User has canceled the payment. Please try again.<br></center>";
}