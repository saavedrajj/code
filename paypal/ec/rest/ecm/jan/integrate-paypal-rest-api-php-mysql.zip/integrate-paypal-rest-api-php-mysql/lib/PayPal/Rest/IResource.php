<?php

namespace PayPal\Rest;

/**
 * Interface IResource
 */
interface IResource
{
}
