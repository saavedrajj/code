<style>
.product{border:1px dashed #999999; background-color:#CCC;height:150px; width:475px}
.title{ font-size:16px; font-weight:bolder; color:#333;clear:both;}
.detail{ font-size:10px;float:left;width:450px}
.submit{ border:dotted #000000; }
.quantity{ }
</style>


<div class="product">
<span class="title">Sony Alpha NEX-5TL : $ 325</span>
<span class="detail">The NEX-5TL is a powerful, pocketable digital camera – great for capturing incredible pictures almost anywhere. </span>
<form action="create.php" method="post">
<input type="hidden" value="1" name="productid"/>
<input type="hidden" value="Sony Alpha NEX-5TL" name="itemname"/>
<input type="hidden" value="325" name="itemprice"/>
<input type="hidden" value="5" name="shipping"/>
<input type="hidden" value="4.2" name="tax"/>
<input type="hidden" value="USD" name="currencycode"/>
<input type="hidden" value="Buy Sony Alpha NEX-5TL" name="paypaldesc"/>
<span class="quantity">
<select name="quantity">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
</select>
</span>
<input class="submit" type="submit" value="Buy Now ($325 Each)" name="subbutton"/>
</form>
</div>



<div class="product">
<span class="title">Brand NEW Apple iPhone 3GS : $ 205</span>
<span class="detail">This item is 100% brand new and from overseas. Stock is limited. </span>
<form action="create.php" method="post">
<input type="hidden" value="2" name="productid" />
<input type="hidden" value="Brand NEW Apple iPhone 3GS" name="itemname" />
<input type="hidden" value="205" name="itemprice"/>
<input type="hidden" value="0" name="shipping"/>
<input type="hidden" value="4.2" name="tax"/>
<input type="hidden" value="USD" name="currencycode"/>
<input type="hidden" value="Buy Brand NEW Apple iPhone 3GS" name="paypaldesc"/>
<span class="quantity">
<select name="quantity">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
</select>
</span>
<input class="submit" type="submit" value="Buy Now ($205 Each)" name="subbutton"/>
</form>
</div>
